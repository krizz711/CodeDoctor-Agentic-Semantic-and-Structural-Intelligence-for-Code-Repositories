from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def validate(path: Path) -> list[str]:
    errors: list[str] = []
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        return [f"Cannot read JSON: {error}"]

    if not isinstance(payload, dict):
        return ["Submission result must be a JSON object"]

    # Check 1: Local metrics format {"metrics": {"mrr": ..., "ndcg_at_10": ...}}
    metrics = payload.get("metrics")
    has_valid_metrics = False
    if metrics is not None:
        if not isinstance(metrics, dict):
            errors.append("metrics must be a dict")
        else:
            for name in ("mrr", "ndcg_at_10"):
                value = metrics.get(name)
                if not isinstance(value, (int, float)) or not 0 <= value <= 1:
                    errors.append(f"metrics.{name} must be a number between 0 and 1")
            has_valid_metrics = True

    # Check 2: Official MTEB TaskResult format {"scores": {"test": [{"ndcg_at_10": ..., "mrr_at_10": ...}]}}
    scores = payload.get("scores")
    has_valid_scores = False
    if scores is not None:
        if not isinstance(scores, dict):
            errors.append("scores must be a dict")
        else:
            # Look inside splits such as "test" or other evaluation splits
            found_split = False
            for split_name, split_metrics in scores.items():
                if isinstance(split_metrics, list):
                    for sub in split_metrics:
                        if isinstance(sub, dict) and ("ndcg_at_10" in sub or "mrr_at_10" in sub):
                            found_split = True
                            for key in ("ndcg_at_10", "mrr_at_10"):
                                if key in sub:
                                    val = sub[key]
                                    if not isinstance(val, (int, float)) or not 0 <= val <= 1:
                                        errors.append(f"scores.{split_name}.{key} must be a number between 0 and 1")
                elif isinstance(split_metrics, dict):
                    if "ndcg_at_10" in split_metrics or "mrr_at_10" in split_metrics:
                        found_split = True
                        for key in ("ndcg_at_10", "mrr_at_10"):
                            if key in split_metrics:
                                val = split_metrics[key]
                                if not isinstance(val, (int, float)) or not 0 <= val <= 1:
                                    errors.append(f"scores.{split_name}.{key} must be a number between 0 and 1")
            if found_split:
                has_valid_scores = True
            else:
                errors.append("scores must contain evaluation split with ndcg_at_10 / mrr_at_10")

    # Check 3: Legacy task_results
    task_results = payload.get("task_results")
    if task_results is not None and not isinstance(task_results, list):
        errors.append("task_results must be a list when present")

    predictions = payload.get("predictions")
    if predictions is not None and not isinstance(predictions, list):
        errors.append("predictions must be a list when present")

    if not has_valid_metrics and not has_valid_scores and not task_results:
        errors.append("Expected local metrics or MTEB scores/task_results containing ndcg_at_10 and mrr_at_10")

    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate a local or MTEB retrieval result JSON.")
    parser.add_argument("result", type=Path)
    args = parser.parse_args()
    errors = validate(args.result)
    if errors:
        for error in errors:
            print(f"ERROR: {error}")
        return 1
    print(f"Valid retrieval result: {args.result}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
