"""Parsing and chunking utilities."""
