"""CodeDoctor application package."""
