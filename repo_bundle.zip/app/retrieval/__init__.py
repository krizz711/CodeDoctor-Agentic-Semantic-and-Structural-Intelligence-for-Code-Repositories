"""CPU retrieval components."""
